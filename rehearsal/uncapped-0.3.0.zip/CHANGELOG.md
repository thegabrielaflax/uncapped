# What's new in Uncapped

## 0.3.0 — first release
- **Discover.** A short interview in the chat about your work, what people ask you for and the week you have. Talk instead of typing if you like (Wispr Flow, Willow Voice or Claude's own dictation). The panel shows what's saved and how many questions are left.
- **Your Portfolio Garden.** Eight to twelve ideas you could get paid for, drawn from your own experience, shown as cards. Open any idea to see what you'd do, what the buyer gets, who'd buy it and when, a price and time to test, and how to test it first. Uncapped's pick shows where it would start.
- **Start with one offer.** Choose an idea and build its two plans from the top of your garden.
- **First 10 Customers.** Ten people or routes to them, your first move, and a first message for each, written with you in the chat in your own voice. Once two messages are saved, "See what to ask" gives you a guide for your calls. Each person has a record you can update as things move.
- **Your Substack strategy.** Who you're writing for, their week, series to come back to, and ten posts in order: an intro story first, then methodology posts and audience builders. Every post has a full brief: the idea, where to open, the story beat by beat, and where to land it. Notes are ready to copy.
- **After your first conversations,** tell the chat what happened. Uncapped saves it and helps you decide what to change.
- **More than one kind of buyer?** Offers for different buyers keep their own plans and Substack.
- **Your work stays yours.** Everything is saved in your Uncapped folder. Updates never change it.
- **Help.** Feedback or help in the panel prepares a note to Gabriela as a draft in your email app.
