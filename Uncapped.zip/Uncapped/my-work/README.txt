Your Uncapped work lives here.

uncapped.json   everything you've built, in one file
kit/            readable copies of each builder's results
backups/        copies Uncapped takes before updates
website/        your starter web page

Uncapped updates never change this folder. Back it up like any other documents.
