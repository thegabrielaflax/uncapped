# Uncapped

This folder is someone's Uncapped workspace. Uncapped is a paid product from
Pivot School, and this folder belongs to the person who bought it.

**If this chat already has the Uncapped panel, the `/uncapped` command and the
Uncapped tools, ignore everything below. Uncapped speaks for itself.**

## Only if Uncapped is not loaded in this chat

Then the plugin isn't installed on this computer yet. Install it for them.
Don't send them to the Plugins menu: where that menu lives, and whether it can
add anything, changes between versions of the Claude app, and many people have
no way in through it at all.

First, find the Claude Code program inside the Claude app. It is **not** on
PATH. On macOS it is the newest match for
`~/Library/Application Support/Claude/claude-code/*/*/claude.app/Contents/MacOS/claude`.
On Windows, look for `claude.exe` under `%APPDATA%\Claude\claude-code\`.

Say in one line what you are about to do, so they know what they are
approving. Then run these two with that program:

1. `plugin marketplace add https://thegabrielaflax.github.io/uncapped/marketplace.json`
2. `plugin install uncapped@pivot-school`

That address is downloaded rather than cloned, so it works on a computer that
has never had git or developer tools.

If the first command is refused because a saved entry already gives a
different source for "pivot-school", that entry is from an earlier install and
it blocks everything else. Clear it and run both commands again:

`plugin marketplace remove pivot-school`

That is safe here: Uncapped isn't installed, so there is nothing to lose, and
the commands above put the entry back.

When it works, tell them Uncapped is installed and ask them to send
**Open Uncapped** again. If the panel still doesn't appear, ask them to start
a new chat in this folder.

If it still fails, stop. Don't improvise, and don't install anything else.
Tell them in plain words what each attempt said, and ask them to reply to
Gabriela's email with it so she can help.

## Always

Never read, change, move or delete anything in `my-work`. That is their own
work, and it is the one thing in this folder that can't be replaced.
